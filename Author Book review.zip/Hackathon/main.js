function test()
        {
            var userInput = document.getElementById("UserInput").value;
            //console.log(userInput);
            //document.getElementById("dis").innerText=userInput;
            let xhr = new XMLHttpRequest;
    
    xhr.addEventListener('load',function(){
        console.log(JSON.parse(this.responseText));
        let r=JSON.parse(this.responseText);
        for(var i=0;i<r.items.length;i++)
        {
            var ans=[r.items[i].volumeInfo.title,
            r.items[i].volumeInfo.publisher,
            r.items[i].volumeInfo.authors,
            r.items[i].volumeInfo.description,
            r.items[i].volumeInfo.averageRating,
            r.items[i].volumeInfo.imageLinks.thumbnail,

        ]
            console.log(r.items[i].volumeInfo.title);
            li=document.createElement('li');
            li.innerHTML=`
                    <br>Book Title : `+ans[0]+`
                    <br>
                    <br><img src="`+ans[5]+`">
                    <br>
                    <br>Publisher: `+ans[1]+`
                    <br>
                    <br>Author: `+ans[2]+`
                    <br>
                    <br>Description: `+ans[3]+`
                    <br>
                    <br>Average Rating: `+ans[4]+`
                    <hr>

            `;
            var list=document.getElementById('dis');
            list.insertBefore(li,list.childNodes[0]);
        }
    });
    xhr.addEventListener('error',function(){
        
    });
   // xhr.open('GET','https://api.nytimes.com/svc/books/v3/reviews.json?author='+name+'&api-key=5SumyWOUoWc7kTXYBzixUtQZ0ailCker');
   xhr.open('GET','https://www.googleapis.com/books/v1/volumes?q='+userInput+'');
    xhr.send();
        }