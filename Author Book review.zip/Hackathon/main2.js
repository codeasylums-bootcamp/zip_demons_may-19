function test()
{
var userInput = document.getElementById("UserInput").value;
let xhr = new XMLHttpRequest;
    
xhr.addEventListener('load',function(){
    console.log(JSON.parse(this.responseText));
    let r=JSON.parse(this.responseText);
    //document.getElementById('dis').innerText = r.results[0].book_title;
    //document.getElementById('dis1').innerText = r.results[0].book_author;
    //document.getElementById('dis2').innerText = r.results[0].url;

        //console.log(ans[0]);
        for(var i=0;i<r.results.length;i++)
        {

            var ans=[r.results[i].book_title, r.results[i].url,r.results[i].link , r.results[i].byline , r.results[i].summary , r.results[i].isbn13 ];
            //console.log(r.items[i].volumeInfo.title);
            li=document.createElement('li');
            li.innerHTML=`
                    <br>Book Title : `+ans[0]+`
                	<br>Review Link : <a href="`+ans[1]+`">Go to Review</a>
                    <br>Publication dt: `+ans[2]+`
                	<br>Summary: `+ans[4]+`
                	<br>isbn13: `+ans[5]+`
                    <hr>

            `;
            var list=document.getElementById('dis');
            list.insertBefore(li,list.childNodes[0]);
        }
    
});
xhr.addEventListener('error',function(){
    
});
   // var name ="Michelle+Obama";
    xhr.open('GET','https://api.nytimes.com/svc/books/v3/reviews.json?author='+userInput+'&api-key=5SumyWOUoWc7kTXYBzixUtQZ0ailCker');
    xhr.send();
}